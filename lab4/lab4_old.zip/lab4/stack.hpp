// stack header file created by 
//Samin Moradkhan and James Ryan Martin 
//July 2022 
#ifndef STACK_H
#define STACK_H

#include <stdio.h>
#include <iostream>
#include <cstddef>
#include <vector>

using namespace std;

// using template to generalize stack class and member functions
template<class T> struct StackFrame; 
template<class T> using StackFramePtr = StackFrame<T>*;

template<class T>
struct StackFrame 
{
    T data;
    StackFrame *link;
};


template<class T>
class Stack 
{
public:
    //default constructor
    Stack();
    //destructor 
    ~Stack();
    //copy constructor 
    Stack(const Stack<T>& copy);
    //check if the stack is empty 
    bool empty() const;
    //helper function for reverse 
    void insert_bottom(T val);
    //overloaded assignment operator
    Stack<T>& operator =(Stack<T>& ST);
    //adding to the top of the stack
    void push(T val);
    //removing and returning the top value of the stack 
    T pop(); 
    //returns the pointer to the top of the stack
    StackFramePtr<T> peek() const;
    //reversing the content of the stack 
    StackFramePtr<T> reverse();
    //retruns the value at the top of the stack
    T  get_val();
private:
    StackFramePtr<T> top;
};

//prints the stack from top to bottom
template<class T>
void printStack (const Stack<T>& s);
#endif