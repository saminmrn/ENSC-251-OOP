//date.cpp to implement your class
#include "date.hpp"
#include <iostream>
#include <cstdlib>
#include <string>
using std::ostream;
using namespace std; 

//Holiday Dates through summer school days
const Date Victoria_Day(23, 5); 
const Date Canada_Day(1, 7);
const Date BC_Day(1, 8);

//Weekend Dates in each month
const int  May_weekend[6]= {14,15,21,22,28,29};
const int June_weekend[8]= {4,5,11,12,18,19,25,26};
const int July_weekend[10]= {2,3,9,10,16,17,23,24,30,31};
const int August_weekend[2]= {6,7};

//default constructor
//sets the date to the first day of summer term 
Date:: Date()
{
    day=9; 
    month=5; 
    appointed[48]={false};  

}

//Constructor 
//Creates a date object with the given day and month if they are in valid range 
Date:: Date(int day_new, int month_new)
{

    day= day_new; 
    month= month_new; 
    appointed[48]={false};
}

//Friend Function equal
//Compares two dates and returns true if they are the same date 
const bool equal(const Date & date_1, const Date & date_2)
{
    bool result= (date_1.day== date_2.day)&&(date_1.month==date_2.month); 
    return result; 
}

//Get Functions 

//returns the month of the appointment  
int Date:: getMonth()
{
    return month; 
}
//returns the day of the appointment 
int Date:: getDay()
{ 
    return day; 
}

//returns the index of the appointment from the appointed array 
bool Date:: getAppointment(int i)
{

    return appointed[i]; 
}

//Set Functions
//sets the date of the appointment if the parameters are in valid ramge 
void Date:: setDate(int day_new, int month_new)
{
    day= day_new; 
    month= month_new; 
}

//Function to set the appointment time 
//has 4 inputs that include the starting hour and minute as well the ending hour and minute 
//If those time slots are free, they can be booked in this function 
void Date:: setAppointment(int h1, int m1, int h2,int m2)
{

    for (int i=0; i<48 ; i++) 
    {
        appointed[i]=0; 
    }
    int a= (h2*60)+m2; // find the starting minute of the appointment 
    int b= (h1*60)+m1; //find the ending minute of the appointment 
    int duration= (a-b)/30; // find the duration of the aappointment 

    if (m1==0) //if the time starts at a whole hour the corresponding index in the appointed array is 2*h 
    {
        int start_index= 2*h1; 
        for (int i=start_index; i<(start_index+duration); i++)
        {   
            if (appointed[i]==false )
            {
                appointed[i]= true; 
            }
            else 
            {
                cout<<"This time slot "<<i <<" is already booked."<<endl; 
            }  
            
        }
    }
    else if (m1==30)//if the time starts at an hour and half the corresponding index in the appointed array is 2*h+1
    {
        int start_index= (2*h1)+1; 
        for (int i=start_index; i<(start_index+duration); i++)
        {
            if (appointed[i]==false)
            {
                appointed[i]= true;
            }
            else 
            {
                cout<<"This time slot is already booked."<<endl; 
            }  
        }
    }
    
} 

//Take a date object and verifies if the date is a holiday or not 
//returns true if the input date is a holiday
bool Date:: isHoliday(const Date & holiday)
{
    if ( equal(holiday, Canada_Day)|| equal(holiday, Victoria_Day) || equal(holiday, BC_Day))
    {
        cout<<"This is a holiday"<<endl; 
        return true; 
    }
    else 
    {
        return false; 
    }
} 

//Check if the calling object is a weekend day
//The weekend days are declared in an array on the top
bool Date:: isWeekend()
{
    if (this->month== 5)//May
    {
        for (int i=0; i<6; i++)//has 6 weekend days
        {
            if (this->day==May_weekend[i])
                return true;   
        }   
    }
    else if (this-> month==6)//June
    {
        for (int i=0; i<8; i++)//has 8 weekend days
        {
            if (this-> day==June_weekend[i])
                return true; 
        }
    }
    else if (this-> month==7)//July
    {
        for (int i=0; i<10; i++)//has 10 weekend days
        {
            if (this-> day==July_weekend[i])
                return true; 
        }
    }
    else if (this->month ==8)//August  
    {
        for (int i=0; i<2; i++)//has 2 weekend days
        {
            if (this->day==August_weekend[i])
                return true;   
        }
    }
    return false; 
}

/* Function isValid checks if a user input date falls within the
valid date range as described in our assumptions. If they do not, print out the error
message, and return false.*/
bool Date:: isValid(int day, int month)
{
    if (month<5 || month >9)
    {
        cout<<"Month is not in  acceptable range."<<endl; 
        return 0; 
    }
    
    //May
    else if (month==5 )
    {
        if (day>31 || day<9)        
        {       
            cout<< "Day is not acceptable in May, the range is 9th to 31st."<<endl; 
            return 0;
        }
    }
    //June
    else if (month==6 )
    {
        if (day>31 || day<1)        
        {       
            cout<< "Day is not acceptable in June, the range is 1st to 31st."<<endl; 
            return 0;
        }
    }
    //July 
    else if (month==7 )
    {
        if (day>30 || day<1)
        {       
            cout<< "Day is not acceptable in July, the range is 1st to 30th."<<endl; 
            return 0;
        }
    }
    //August 
    else if (month==8)
    {
        if (day>8 || day<1)        
        {       
            cout<< "Day is not acceptable in August, the range is 1st to 8th."<<endl; 
            return 0;
        }
    }
    return 1; 
}

void Date::output(ostream& outs)
{    
    if (isValid(day, month))
    {
        if(day<10)
        {
            outs << "Your date: " << "0" << month << "/" << "0" << day <<" ";
        }
        else
        {
            outs << "Your date: " << "0" << month << "/" << day <<" ";
        }

        if (isHoliday(Date(day,month)))
        {
            outs << " is a holiday.";
        }
        else if (this->isWeekend())
        {
            outs << " is a weekend.";
        }
        else
        {
            outs << " is a weekday and you may book an appointment.";
        }
        outs << endl;
    }
    else 
    {
        cout<< "There is no information for this date"<<endl; 
    }
 
}



/*
e. Implement printFreeTimeSlots member function to print all free time slots of the
day that haven’t been booked. */
void Date:: printFreeTimeSlots()
{
    if (isValid(day, month) && !(isHoliday(Date(day, month))) && !(this->isWeekend()))
    {
        //be able to show two 0s (00) for the starting or ending minutes
        int start_hour=0; 
        int start_minute1=0; 
        int start_minute2=0; 
        int end_hour=0; 
        int end_minute1=0;
        int end_minute2=0;  
        cout<< "Here are the free time slots you can book:"<<endl;
        for (int i=0; i<48; i++)
        {   
       
            if (appointed[i]==false)
            {
            
                start_hour= i/2; 
                if (i%2==0)//if the index is even 
                {
                    start_minute1= 0;
                    start_minute2=0;
                    end_minute1=3; 
                    end_minute2=0;
                    end_hour= (i/2);
                }
                else //if the index is odd 
                {
                    start_minute1= 3;
                    start_minute2= 0; 
                    end_minute1=0;
                    end_minute2=0;  
                    end_hour= (i/2)+1; 
                }

                cout<< "from "<< start_hour<<":"<<start_minute1<<start_minute2;
                cout<<" to "<<end_hour<<":"<<end_minute1<<end_minute2<<endl; 
            }
        }
    }
    else 
    {
        cout<<"There canot be appointments made on this day:"<<endl; 
    }

} 

/*Implement printAppointedTimeSlots member
function to print all time slots of the day that have already been booked. Note your
print out information should be easy to understand, e.g., print out the actual time
slots instead of the array indices.*/
void Date:: printAppointedTimeSlots()
{
    if (isValid(day, month) && !(isHoliday(Date(day, month))) && !(this->isWeekend()))
    {   
        //needed two variable for the minute to be able to print 00 as the minutes of a whole hour 
        int start_hour=0; 
        int start_minute1=0; 
        int start_minute2=0; 
        int end_hour=0; 
        int end_minute1=0;
        int end_minute2=0; 
        cout<< "Here are the booked time slots for month "<< month<< " day " <<day <<endl;
        for (int i=0; i<48; i++)
        {
       
            if (appointed[i]==true)
            {
                //the index of the starting hour is 2*starting hour
                start_hour= i/2; 
                if (i%2==0)//if the index is even the appointment end at xx:30
                {
                    start_minute1= 0;
                    start_minute2=0;
                    end_minute1=3; 
                    end_minute2=0;
                    end_hour= (i/2);
                }
                else //if the index is odd the appointment ends at xx:00
                {
                    start_minute1= 3;
                    start_minute2= 0; 
                    end_minute1=0;
                    end_minute2=0;  
                    end_hour= (i/2)+1; 
                }

                cout<< "from "<< start_hour<<":"<<start_minute1<<start_minute2;
                cout<<" to "<<end_hour<<":"<<end_minute1<<end_minute2<<endl; 
                
            }
        }
    }
    else 
    {
        cout<<"There cannot be appointments made on this day. "<<endl; 
    }   
} 
